import React, { Component } from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import AsyncStorage from '../components/node_modules/@react-native-community/async-storage';
import { inject, observer } from 'mobx-react';

@inject('loginScreen')
@observer
class ProfileScreen extends Component {
    constructor(props) {
        super(props);
        this.props = props;
    }

    componentDidMount() {
        getUserDetail = async () => {
            const email = await AsyncStorage.getItem('token');
            this.props.loginScreen.getUserFromDatabase(email);
        }
        getUserDetail();
    }

    render() {
        const { userData } = this.props.loginScreen;
        return (
            <View style={{ flex: 1 }}>
                <Image source={{ uri: userData.imagelocation }}
                    style={styles.picker} />
                <Text style={styles.text}>{userData.username}</Text>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    picker: {
        height: 100,
        width: 100,
        borderRadius: 45,
        borderWidth: 4,
        alignSelf: 'center',
    },
    text: {
        fontSize: 28,
        color: '#ff8c00'
    }
})

export default ProfileScreen;