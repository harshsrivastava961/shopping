import React, {Component} from 'react';
import Realm from 'realm';
import {Text,View,TextInput,TouchableOpacity,Alert,StyleSheet,Image} from 'react-native';
import {addUserToDatabase} from '../database/DataHandler';
import LinearGradient from 'react-native-linear-gradient';
import { AuthSchema } from '../database/Schema';
import ImagePicker from 'react-native-image-picker';

export default class SignupScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            username : '',
            email: '',
            password: '',
            imageLocation : '',
            isEmailValid: false,
            isPasswordValid: false,
            isUsernameValid : false,
            alreadyRegistered : false,
        };
    }
    validateUsername = () => {
        const usernameReg = /^[a-zA-Z0-9_]+$/;
        (usernameReg.test(this.state.username)) ? this.setState({ isUsernameValid: true }) : this.setState({ isUsernameValid: false });
    }
    validateEmail = () => {
        const emailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        (emailReg.test(this.state.email)) ? this.setState({ isEmailValid: true }) : this.setState({ isEmailValid: false });
    }
    validatePassword = () => {
        const passwordReg = /^[a-zA-Z0-9_]+$/;
        (passwordReg.test(this.state.password)) ? this.setState({ isPasswordValid: true }) : this.setState({ isPasswordValid: false });
    }

    registerUser = async () =>{
        try{
            const realm = new Realm({schema: [AuthSchema]})
            const getAllUserFromDatabase = realm.objects('user_details')
            if (this.state.username === '' || this.state.email == '' || this.state.password == '') {
                Alert.alert('Empty field', 'Please Enter some value in each field')
            }
            else if (( this.state.isUsernameValid && this.state.isEmailValid && this.state.isPasswordValid)) {
                for(let getUser of getAllUserFromDatabase){
                    if(getUser.email == this.state.email)
                        this.setState({alreadyRegistered : true})
                }
                if(this.state.alreadyRegistered)
                {
                    Alert.alert('Failed','You already registered .. try diffrent credential')
                }
                else{
                    const userData = {
                        username : this.state.username,
                        email : this.state.email,
                        password : this.state.password,
                        imagePath : this.state.imagePath
                    }
                    await addUserToDatabase(userData);
                    Alert.alert('Registered','your credential is stored');
                    this.props.navigation.navigate('LoginScreen')
                }      
            }
            else if (!this.state.isUsernameValid ){
              Alert.alert("Valid UserName Required")
            }
            else if (!this.state.isEmailValid ){
              Alert.alert("Valid Email Required")
            }
            else if (!this.state.isPasswordValid ){
              Alert.alert("Valid Password Required")
            }
        }catch(error){
            alert(error);
        }
        
    }

    chooseFile = () => {
      var options = {
        title: 'Select Image',
        customButtons: [
          { name: 'customOptionKey', title: 'Custom Option' },
        ],
        storageOptions: {
          skipBackup: true,
          path: 'images',
        },
      };
      ImagePicker.showImagePicker(options, response => {
        console.log('Response = ', response);
  
        if (response.didCancel) {
          console.log('image picker cancelled by user');
        } else if (response.error) {
          console.log('ImagePicker Error: ', response.error);
        } else if (response.customButton) {
          console.log('User tapped custom button: ', response.customButton);
          alert(response.customButton);
        } else {
          let source = { uri: 'data:image/jpeg;base64,' + response.data };
          this.setState({
            imagePath: source,
          });
        }
      });
    };

  render() {
    const { navigate } = this.props.navigation;
    return (
        <View style={styles.body}>
                <LinearGradient
                style={styles.top}
                colors={['#ff8c00','#ff8c00']}>
                    <View>
                        <TouchableOpacity style={styles.imagePicker}
                          onPress ={this.chooseFile.bind(this)}
                          >
                            <Image 
                              source={{ uri: this.state.imagePath.path}} 
                              style={styles.imagePicker} />
                          </TouchableOpacity>
                    </View>
                </LinearGradient>
            
            <View style={styles.bottom}>
                <View style={styles.productLocation}>
  
                    <TextInput
                    placeholder="Username"
                    autoCapitalize="none"
                    style={styles.textInput}
                    value={this.state.username}
                    onChangeText={(username) => {this.setState({username: username},() =>this.validateUsername())}}
                                                   
                    />
                </View>
                <View style={styles.productLocation}>
                    <TextInput
                    placeholder="Email"
                    autoCapitalize="none"
                    style={styles.textInput}
                    value={this.state.email}
                    onChangeText={(email) => {this.setState({email: email},() => this.validateEmail())}}
                    />
                </View>
                <View style={styles.productLocation}>
                    <TextInput
                    placeholder="Password"
                    secureTextEntry={true}
                    autoCapitalize="none"
                    style={styles.textInput}
                    value={this.state.password}
                    onChangeText={(password) => {this.setState({password: password},() => this.validatePassword())}}
                    />
                </View>
                <TouchableOpacity onPress={() => this.registerUser()}>
                    <LinearGradient
                    style={styles.button}
                    colors={['#ff8c00','#ff8c00']}>
                    <Text style={styles.buttonText}>Sign Up</Text>
                    </LinearGradient>
                </TouchableOpacity>
                <TouchableOpacity
                    onPress={() => navigate('LoginScreen')}>
                    <LinearGradient
                    style={styles.button}
                    colors={['#ff8c00','#ff8c00']}>
                    <Text style={styles.buttonText}>Back</Text>
                    </LinearGradient>
                </TouchableOpacity>
            </View>
            
        </View>
    );
  }
}

const styles = StyleSheet.create({
  body: {
    flex: 1,
    backgroundColor: 'floralwhite',
  },
  top: {
    flex: 0.3,
    backgroundColor: '#ffffff',
    justifyContent: 'center',
  },
  bottom: {
    flex: 0.7,
    marginTop: 30,
    paddingHorizontal: 25,
    justifyContent: 'flex-start',
  },
  productLocation: {
    flexDirection: 'row',
    paddingTop: 15,
    paddingBottom: 30,
    alignContent: 'center',
    alignSelf: 'center',
  },
  imagePicker{
    height : 120,
    width : 120,
    borderRadius : 60,
    borderWidth :3,
    alignSelf : 'center',
  },
  headingText: {
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 25,
    color: '#fff',
    paddingBottom: 5,
  },
  textInput: {
    flex: 1,
    marginTop: -15,
    paddingLeft: 10,
    color: '#5C5C5C',
    fontSize: 20,
    fontWeight : 'bold',
    borderBottomColor: '#42275a',
    borderBottomWidth: 3,
  },
  button: {
    width: '100%',
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    marginTop: 20,
    backgroundColor: '#0BDB8F',
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  picker: {
    height: 40,
    width: 120,
    borderWidth: 2,
    borderColor: 'floralwhite',
  },
  divider :{
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 25,
    color: '#42275a',
    paddingTop : 15,
  }
});
