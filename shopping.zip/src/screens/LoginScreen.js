import React, {Component} from 'react';
import {Text,View,TextInput,TouchableOpacity,Alert,StyleSheet,} from 'react-native';
import { inject, observer } from 'mobx-react';
import AsyncStorage from '../components/node_modules/@react-native-community/async-storage'; 
import LinearGradient from 'react-native-linear-gradient';

@inject('loginScreen')
@observer
class LoginScreen extends Component {
    constructor(props) {
        super(props);
        this.props = props;
        this.state = {
            email: "",
            password: '',
            isEmailValid: false,
            isPasswordValid: false,
            userValid : false
        }
    }

    validateEmail = () => {
        const emailReg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        (emailReg.test(this.state.email)) ?( this.props.loginScreen.getUserFromDatabase(this.state.email), this.setState({ isEmailValid: true })) : this.setState({ isEmailValid: false });
    }
    validatePassword = () => {
        const passwordReg = /^[a-zA-Z0-9_]+$/;
        (passwordReg.test(this.state.password)) ? this.setState({ isPasswordValid: true }) : this.setState({ isPasswordValid: false });
    }

    AuthenticateUser = async () =>{
        try{
            const {userData} = this.props.loginScreen;
            console.log(userData)
            if ((this.state.email == '' && this.state.password == '')) {
                Alert.alert('Please provide password')
            }
            else if (this.state.isEmailValid && this.state.isPasswordValid) {
                for (let user of userData) {
                  if (user.email === this.state.email && user.password === this.state.password) {
                        this.setState({userValid : true})
                      }
                }
                if(this.state.userValid){
                  await AsyncStorage.setItem('token', this.state.email)
                  this.props.navigation.navigate('UserScreen')
                }
                else{
                  Alert.alert('Wrong input')
                }
            }
            else {
                Alert.alert('Wrong input')
            }
        }catch(error){
            alert(error);
        }
        
    }

    handleFacebookLogin () {
      LoginManager.logInWithReadPermissions(['public_profile', 'email', 'user_friends']).then(
        function (result) {
          if (result.isCancelled) {
            console.log('Please Login Again')
          } else {
            console.log('Login success: ' + result.grantedPermissions.toString())
            this.props.navigation.navigate('UserScreen');
          }
        },
        function (error) {
          console.log('Login fail: ' + error)
        }
      )
    }

  render() {
    const { navigate } = this.props.navigation;
    return (
        <View style={styles.container}>
            
                <LinearGradient
                style={styles.top}
                colors={['#ff8c00', '#ff8c00']}>
                    <View>
                        <Text style={styles.topText}>Welcome!!</Text>
                    </View>
                </LinearGradient>
            
            <View style={styles.middle}>
                <View style={styles.productLocation}>
                  
                    <TextInput
                    placeholder="Email"
                    autoCapitalize="none"
                    style={styles.textInput}
                    value={this.state.email}
                    onChangeText={(email) => {this.setState({email: email}, () => this.validateEmail())}}
                    />
                </View>
                <View style={styles.productLocatio}>
                    <TextInput
                    placeholder="Password"
                    secureTextEntry={true}
                    autoCapitalize="none"
                    style={styles.textInput}
                    value={this.state.password}
                    onChangeText={(password) => {this.setState({password: password}, () => this.validatePassword())}}
                    />
                </View>
                <TouchableOpacity 
                    onPress={() => this.AuthenticateUser()}
                    style={styles.buttonStyle}>
                    <LinearGradient
                      style={styles.buttonStyle}
                      colors={['#ff8c00', '#ff8c00']}>
                      <Text style={styles.buttonFont}>Sign In</Text>
                    </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity
                    onPress={() => navigate('SignupScreen')}
                    style={styles.buttonStyle}>
                    <LinearGradient
                      style={styles.buttonStyle}
                      colors={['#ff8c00', '#ff8c00']}>
                      <Text style={styles.buttonFont}>Sign Up</Text>
                    </LinearGradient>
                </TouchableOpacity>
            </View>
        </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'floralwhite',
  },
  middle: {
    flex: 0.8,
    marginTop: 30,
    paddingHorizontal: 25,
    justifyContent: 'flex-start',
  },
  textInput: {
    flex: 1,
    marginTop: -15,
    paddingLeft: 10,
    color: '#5C5C5C',
    fontSize: 20,
    fontWeight : 'bold',
    borderBottomColor: '#000000',
    borderBottomWidth: 3,
  },
  productLocation: {
    flexDirection: 'row',
    paddingTop: 15,
    paddingBottom: 30,
    alignContent: 'center',
    alignSelf: 'center',
  },
  top: {
    flex: 0.5,
    backgroundColor: '#ff8c00',
    justifyContent: 'center',
  },
  topText: {
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 25,
    color: '#fff',
    paddingBottom: 5,
  },
  buttonFont: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
 
  buttonStyle: {
    width: '100%',
    height: 35,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 25,
    marginTop: 10,
    backgroundColor: '#ff8c00',
  },
  
});

export default LoginScreen;