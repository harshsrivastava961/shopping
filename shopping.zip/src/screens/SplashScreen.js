import React, {useEffect, useState, Component} from 'react';
import {Text, View, StyleSheet, Image} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import AsyncStorage from '../components/node_modules/@react-native-community/async-storage';
import { inject, observer } from 'mobx-react';

@inject('loginScreen')
@observer
export default class SplashScreen extends Component {
  constructor(props){
    super(props);
    this.props = props;
  }

  componentDidMount(){
    const checkToken = async () =>{
      const token = await AsyncStorage.getItem('token');
      if(token == null)
          {
              setTimeout(() => this.props.navigation.navigate('LoginScreen'), 3000)
          }
      else{   
        this.props.signIn.getUserFromDatabase(token);
            setTimeout(() => this.props.navigation.navigate('UserScreen'), 3000)
        }
      }
      checkToken();
  }
    
  render(){

    return (
      <LinearGradient style={styles.container} colors={['#ff8c00','#ff8c00']}>
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.headerText}>Hi there!</Text>
          </View>
          <View style={styles.footer}>
             
              <Image
                  source ={require('../assets/icon.png')}
                  style={styles.appIcon}
              />
          </View>
        </View>
      </LinearGradient>
    );
  } 
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flex: 0.4,
    justifyContent: 'flex-end',
  },
  headerText: {
    color: '#000000',
    fontWeight: 'bold',
    fontSize: 25,
    marginLeft: 20,
  },
  footer: {
    flex: 4,
    backgroundColor: 'floralwhite',
    borderTopWidth : 2,
    borderTopColor : '#ff8c00'
  },
  appIcon :{
    height : 150,
    width : 150,
    alignSelf : 'center',
    marginTop : 300
  },
});
