import React, { Component } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Image, FlatList, Button } from 'react-native';
import { inject, observer } from 'mobx-react';
import AsyncStorage from '../components/node_modules/@react-native-community/async-storage';

@inject('cart')
@observer
class Cart extends Component {
    constructor(props) {
        super(props);
        this.props = props;
        this.state = {
            productCount: 1,
        }
    }
    decreaseCounter = () => {
        if (this.state.productCount > 1)
            this.setState({ productCount: this.state.productCount - 1 });
        else
            alert('Minimum item count 1')
    }
    increaseCounter = () => {
        if (this.state.productCount < 10)
            this.setState({ productCount: this.state.productCount + 1 });
        else
            alert('Maximum item count 10')
    }
    componentDidMount() {
        const userEmail = AsyncStorage.getItem('token');
        this.props.cart.getUserCartFromDatabase(userEmail);
    }

    render() {
        const { navigation } = this.props;
        const { itemDetails, fetchProductDetails, itemReview, fetchProductReview } = this.props.cart;

        return (
            <View style={styles.container}>

                <View style={styles.top}>
                    <ScrollView>
                        <Image source={{ uri: itemDetails.images }} style={styles.imageView} />
                        <Text style={styles.text}>{itemDetails.name}</Text>
                        <View style={styles.view}>
                            <View style={styles.viewLeft}>
                                <Text style={styles.pricetext}>Price - {itemDetails.price} </Text>
                                <Text style={styles.text}>Discounted Price - {itemDetails.special_price}</Text>
                            </View>
                            <View style={styles.rightview}>
                                <TouchableOpacity style={styles.counter} onPress={() => this.decreaseCounter()}>
                                    <Text style={styles.buttonfont}> - </Text>
                                </TouchableOpacity>
                                <Text style={styles.counterText}> {this.state.productCount}</Text>
                                <TouchableOpacity style={styles.counter} onPress={() => this.increaseCounter()}>
                                    <Text style={styles.buttonfont}> + </Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                        <View />
                    </ScrollView>
                </View>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#ff8c00',
    },
    pricetext: {
        fontSize: 18,
        padding: 5,
        color: '#a3a5a8',
    },
    top: {
        flex: 1,
        backgroundColor: '#fff',
        marginRight: 5,
        marginLeft: 8,
        marginTop: 5,
        paddingLeft: 10,
        paddingRight: 10,
        justifyContent: 'center'
    },
    imageView: {
        width: 200,
        height: 200,
        margin: 5,
        alignSelf: 'center'
    },
    buttom: {
        flex: 0.09,
        justifyContent: 'flex-start',
    },

    View: {
        flex: 1,
        flexDirection: 'row',
        marginTop: 10,
    },
    rightview: {
        flex: 0.5,
        flexDirection: 'row',
        paddingRight: 20,
        justifyContent: 'flex-end'
    },
    viewLeft: {
        flex: 0.5,
        justifyContent: 'center'
    },
    headingText: {
        fontSize: 25,
        paddingBottom: 10,
        color: '#c9430e',
        fontWeight: 'bold'
    },

    counterText: {
        fontSize: 18,
        padding: 5,
        color: '#11151c',
        fontWeight: 'bold',
        alignSelf: 'center',
        backgroundColor: '#ccccca'
    },
    text: {
        fontSize: 18,
        padding: 5,
        color: '#11151c',
    },
    counter: {
        backgroundColor: '#bdbcb9',
        alignSelf: 'center',
        width: 30
    },
    buttonfont: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#333333',
        alignSelf: 'center',
    },
    footerview: {
        flexDirection: 'row',
        flex: 1,
        backgroundColor: '#e3e3e3',
        borderTopColor: '#ff8c00',
        borderTopWidth: 2
    },

})

export default Cart;