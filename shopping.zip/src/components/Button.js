import React, { Component } from 'react';
import { withNavigation } from 'react-navigation';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { StyleSheet, View, TouchableOpacity } from 'react-native';

class Button extends Component {
    constructor(props) {
        super(props);
        this.props = props;
    }

    render() {
        return (
            <View>
                <TouchableOpacity onPress={() => this.props.navigation.navigate('Cart')}
                    style={styles.Button}>
                    <MaterialCommunityIcons name="cart" color="#11151c" size={25} />
                </TouchableOpacity>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    Button: {
        height: 28,
        width: 28,
        marginRight: 12
    }
})

export default withNavigation(Button);