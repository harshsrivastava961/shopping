import  React  from "react";
import {createStackNavigator} from 'react-navigation-stack';
import {createDrawerNavigator} from 'react-navigation-drawer';
import {createAppContainer, createSwitchNavigator} from '../components/node_modules/react-navigation';
import SplashScreen from '../screens/SplashScreen';
import SignupScreen from '../screens/SignupScreen';
import LoginScreen from '../screens/LoginScreen';
import ProfileScreen from '../screens/ProfileScreen'
import Button from '../components/Button';
import Cart from '../screens/Cart';
import UserScreen from '../screens/UserScreen';
import LogOut from '../components/LogOut';
import ProductDetails from '../screens/ProductDetails';

const DrawerNavigator = createDrawerNavigator({
  ProfileScreen : ProfileScreen,
  UserScreen: UserScreen,
  LogOut : LogOut
 }
);

const StackNavigator = createStackNavigator({
  DrawerNavigator : {
    screen : DrawerNavigator,
    navigationOptions :{
      title: 'UserScreen',
        headerRight: ()=>  (
            <Button />
            ),
        headerStyle: {
          backgroundColor: '#e3e3e3'
        },
        headerTintColor: '#000000',
    }
  },
  ProductDetails : ProductDetails,
  Cart : Cart,
});

const SwitchNavigator = createSwitchNavigator(
  {
    SplashScreen: SplashScreen,
    LoginScreen: LoginScreen,
    SignupScreen: SignupScreen,
    StackNavigator: StackNavigator,
    LogOut : LogOut
  },
  {
    initialRouteName: 'SplashScreen',
  },
);

export default createAppContainer(SwitchNavigator);
