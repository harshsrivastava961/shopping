import { observable, action, computed } from "mobx";
import { getUserFromDatabase } from "../database/DataHandler";

class LoginScreen {
    @observable userData = [];

    @action getUserFromDatabase = (email) => {
        getUserFromDatabase(email).then((res) => {
          this.userData = res;
          console.log(this.userData)
        }).catch((error) => {
          console.log(error);
        });
      };

    @computed get _userData () {
        return this.userData;
    }
}
export default LoginScreen;