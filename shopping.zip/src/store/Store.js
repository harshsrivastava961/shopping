import Cart from './Cart';
import LoginScreen from './LoginScreen';
import ProductDetails from './ProductDetails';
import UserScreen from "./UserScreen";

class Store {
    loginScreen: LoginScreen;
    userScreen : UserScreen;
    productDetails : ProductDetails;
    cart : Cart;

    constructor() {
        this.loginScreen = new LoginScreen(this);
        this.userScreen = new UserScreen(this);
        this.productDetails = new ProductDetails(this);
        this.cart = new Cart(this);
    }
}
export default new Store();